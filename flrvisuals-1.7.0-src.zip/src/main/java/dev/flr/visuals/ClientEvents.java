package dev.flr.visuals;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.GenericMessageScreen;
import net.minecraft.client.gui.screens.LevelLoadingScreen;
import net.minecraft.client.gui.screens.ProgressScreen;
import net.minecraft.client.gui.screens.ReceivingLevelScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import org.joml.Matrix4f;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.util.Mth;
import net.minecraft.world.level.material.FogType;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

public final class ClientEvents {
    private static int frames;
    private static long windowStart = System.nanoTime();

    public static void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(FlrKeys.MENU);
        e.register(FlrKeys.MASTER);
        e.register(FlrKeys.SOUND);
        e.register(FlrKeys.AUTOSWAP);
        e.register(FlrKeys.ZOOM);
    }

    public static void addLayers(EntityRenderersEvent.AddLayers e) {
        for (PlayerSkin.Model skin : e.getSkins()) {
            var r = e.getSkin(skin);
            if (r instanceof PlayerRenderer pr) pr.addLayer(new CosmeticsLayer(pr));
        }
    }

    public static void gui(RenderGuiEvent.Post e) {
        frames++;
        long now = System.nanoTime();
        if (now - windowStart >= 500_000_000L) {
            Config.fps = (int) (frames * 1_000_000_000.0 / (now - windowStart));
            frames = 0;
            windowStart = now;
        }
        Minecraft mc = Minecraft.getInstance();
        GuiGraphics g0 = e.getGuiGraphics();
        Notify.render(g0);
        if (Config.master && !mc.options.hideGui && mc.screen == null) {
            TargetEsp.render(g0, e.getPartialTick().getGameTimeDeltaPartialTick(false));
            if (Config.coords) coords(g0, mc);
        }
        if (!Config.master || !Config.hud || mc.options.hideGui || mc.screen != null) return;
        GuiGraphics g = e.getGuiGraphics();
        String text = "FLR  " + Config.fps + " FPS";
        int w = mc.font.width(text);
        int c = Config.color();
        g.fill(5, 5, 5 + w + 10, 20, 0x99101018);
        g.fill(5, 5, 7, 20, c);
        g.drawString(mc.font, text, 11, 9, c, false);
    }

    public static void fogColor(ViewportEvent.ComputeFogColor e) {
        if (!Config.master || Config.fogTint <= 0 || e.getCamera().getFluidInCamera() != FogType.NONE) return;
        int c = Config.color();
        float t = (float) Config.fogTint * 0.6f;
        e.setRed(Mth.lerp(t, e.getRed(), (c >> 16 & 255) / 255f));
        e.setGreen(Mth.lerp(t, e.getGreen(), (c >> 8 & 255) / 255f));
        e.setBlue(Mth.lerp(t, e.getBlue(), (c & 255) / 255f));
    }

    public static void fogRender(ViewportEvent.RenderFog e) {
        if (!Config.master || Config.fogDensity <= 0 || e.getType() != FogType.NONE) return;
        float far = Mth.lerp((float) Config.fogDensity, 220f, 28f);
        e.setNearPlaneDistance(far * 0.1f);
        e.setFarPlaneDistance(far);
        e.setCanceled(true);
    }

    /** Чёрный фон с волнами для главного меню и экранов загрузки; кнопки рисуются поверх. */
    public static void screenPre(ScreenEvent.Render.Pre e) {
        if (!Config.menuStyle) return;
        Screen sc = e.getScreen();
        boolean title = sc instanceof TitleScreen;
        String load = null;
        if (sc instanceof ConnectScreen) load = "Connecting to server";
        else if (sc instanceof ReceivingLevelScreen || sc instanceof LevelLoadingScreen) load = "Loading terrain";
        else if (sc instanceof ProgressScreen) load = "Loading";
        else if (sc instanceof GenericMessageScreen) {
            load = sc.getTitle().getString();
            for (GuiEventListener c : sc.children()) {
                if (c instanceof AbstractWidget w && !(c instanceof AbstractButton) && !w.getMessage().getString().isBlank()) {
                    load = w.getMessage().getString();
                    break;
                }
            }
        }
        if (!title && load == null) return;
        e.setCanceled(true);
        var g = e.getGuiGraphics();
        Backdrop.draw(g, sc.width, sc.height);
        if (title) {
            Backdrop.logo(g, sc.width);
            Backdrop.titleExtras(g, sc.width, sc.height);
            int x0 = Integer.MAX_VALUE, y0 = Integer.MAX_VALUE, x1 = 0, y1 = 0;
            for (GuiEventListener c : sc.children()) {
                if (c instanceof AbstractButton b && b.getHeight() == 20 && b.getWidth() >= 90 && b.getY() > sc.height / 5 && b.getY() < sc.height - 30) {
                    x0 = Math.min(x0, b.getX()); y0 = Math.min(y0, b.getY());
                    x1 = Math.max(x1, b.getX() + b.getWidth()); y1 = Math.max(y1, b.getY() + b.getHeight());
                }
            }
            if (x1 > x0) {
                int acc = Config.color() & 0xFFFFFF;
                CosmeticsScreen.rrect(g, x0 - 15, y0 - 15, x1 - x0 + 30, y1 - y0 + 30, 17, 0x3A000000 | acc);
                CosmeticsScreen.rrect(g, x0 - 14, y0 - 14, x1 - x0 + 28, y1 - y0 + 28, 16, 0xB0090A12);
            }
        } else {
            Backdrop.loading(g, sc.width, sc.height, load);
        }
        for (GuiEventListener c : sc.children()) {
            if (c instanceof Renderable r && (title || c instanceof AbstractButton)) r.render(g, e.getMouseX(), e.getMouseY(), e.getPartialTick());
        }
    }

    /** Цветное небо: полупрозрачный градиентный купол вокруг камеры сразу после ванильного неба. */
    public static void sky(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_SKY || !Config.master || !Config.sky) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.level.dimension() != Level.OVERWORLD) return;
        int base = switch (Config.skyMode) {
            case 0 -> Config.color();
            case 1 -> Config.hsb(Config.skyHue, 0.7, 1.0);
            case 3 -> Config.BLACK;
            case 4 -> Config.WHITE;
            default -> Config.hsb((System.currentTimeMillis() % 30000L) / 30000.0, 0.65, 1.0);
        };
        long dt = mc.level.getDayTime() % 24000L;
        float k = (dt > 12600 && dt < 23400) ? 0.3f : 1f;
        float al = (float) Config.skyAlpha * k;
        int top = col(base, 0.9f, al), hor = col(mix(base, 0xFFFFFF, 0.35f), 1f, al * 0.75f), bot = col(base, 0.8f, al * 0.35f);
        Matrix4f m = e.getModelViewMatrix();
        BufferBuilder bb = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        float r = 100f;
        float[][] c = {{-r, -r}, {r, -r}, {r, r}, {-r, r}};
        for (int i = 0; i < 4; i++) {
            float ax = c[i][0], az = c[i][1], bx = c[(i + 1) % 4][0], bz = c[(i + 1) % 4][1];
            bb.addVertex(m, ax, -r, az).setColor(bot); bb.addVertex(m, bx, -r, bz).setColor(bot);
            bb.addVertex(m, bx, 0, bz).setColor(hor); bb.addVertex(m, ax, 0, az).setColor(hor);
            bb.addVertex(m, ax, 0, az).setColor(hor); bb.addVertex(m, bx, 0, bz).setColor(hor);
            bb.addVertex(m, bx, r, bz).setColor(top); bb.addVertex(m, ax, r, az).setColor(top);
        }
        for (float[] p : c) bb.addVertex(m, p[0], r, p[1]).setColor(top);
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        BufferUploader.drawWithShader(bb.buildOrThrow());
        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16 & 255) * (1 - t)) + ((b >> 16 & 255) * t));
        int g = (int) (((a >> 8 & 255) * (1 - t)) + ((b >> 8 & 255) * t));
        int bl = (int) (((a & 255) * (1 - t)) + ((b & 255) * t));
        return r << 16 | g << 8 | bl;
    }

    private static int col(int rgb, float bri, float alpha) {
        int r = Math.min(255, (int) ((rgb >> 16 & 255) * bri)), g = Math.min(255, (int) ((rgb >> 8 & 255) * bri)), b = Math.min(255, (int) ((rgb & 255) * bri));
        return Math.max(0, Math.min(255, (int) (alpha * 255))) << 24 | r << 16 | g << 8 | b;
    }

    private static float zoom = 1f;

    /** Плавный зум по зажатой клавише. */
    public static void fov(ViewportEvent.ComputeFov e) {
        Minecraft mc = Minecraft.getInstance();
        float target = Config.master && mc.screen == null && FlrKeys.ZOOM.isDown() ? 0.22f : 1f;
        zoom += (target - zoom) * 0.2f;
        if (Math.abs(zoom - 1f) > 0.002f) e.setFOV(e.getFOV() * zoom);
    }

    /** Кнопка FLR в главном меню: настройки доступны и вне мира. */
    public static void screenInit(ScreenEvent.Init.Post e) {
        if (!Config.menuStyle || !(e.getScreen() instanceof TitleScreen sc)) return;
        e.addListener(Button.builder(Component.literal("FLR"), b -> Minecraft.getInstance().setScreen(new CosmeticsScreen()))
                .bounds(10, sc.height - 42, 48, 20).build());
    }

    private static void coords(GuiGraphics g, Minecraft mc) {
        if (mc.player == null) return;
        String dir = switch (mc.player.getDirection()) {
            case NORTH -> "N";
            case SOUTH -> "S";
            case WEST -> "W";
            default -> "E";
        };
        String s = "XYZ " + (int) Math.floor(mc.player.getX()) + " " + (int) Math.floor(mc.player.getY()) + " "
                + (int) Math.floor(mc.player.getZ()) + "  " + dir;
        int w = mc.font.width(s) + 16, acc = Config.color() & 0xFFFFFF;
        CosmeticsScreen.rrect(g, 4, 24, w + 2, 18, 9, 0x40000000 | acc);
        CosmeticsScreen.rrect(g, 5, 25, w, 16, 8, 0xCC11121B);
        g.drawString(mc.font, s, 13, 29, 0xFFFFFFFF, false);
    }
}

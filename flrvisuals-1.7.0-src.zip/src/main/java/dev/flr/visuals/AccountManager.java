package dev.flr.visuals;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ProfileKeyPairManager;
import net.minecraft.client.User;
import net.minecraft.core.UUIDUtil;
import net.neoforged.fml.loading.FMLPaths;

/**
 * Переключатель аккаунтов прямо в игре (оффлайн-ники).
 * Хранит только ники (без токенов и паролей). Подмена действует на следующее подключение к серверу.
 * Поля Minecraft.user / profileKeyPairManager открыты через META-INF/accesstransformer.cfg.
 */
public final class AccountManager {
    private static final Pattern NAME = Pattern.compile("^[A-Za-z0-9_]{3,16}$");
    private static final List<String> NAMES = new ArrayList<>();
    private static User original;
    private static ProfileKeyPairManager originalKeys;
    private static boolean loaded;

    private AccountManager() {}

    private static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve("flrvisuals_accounts.txt");
    }

    public static List<String> names() {
        if (!loaded) {
            loaded = true;
            try {
                Path p = file();
                if (Files.exists(p)) {
                    for (String line : Files.readAllLines(p)) {
                        String n = line.trim();
                        if (NAME.matcher(n).matches() && !NAMES.contains(n)) NAMES.add(n);
                    }
                }
            } catch (Exception ignored) {
            }
        }
        return NAMES;
    }

    private static void save() {
        try {
            Files.write(file(), NAMES);
        } catch (Exception ignored) {
        }
    }

    public static boolean valid(String name) {
        return name != null && NAME.matcher(name).matches();
    }

    public static boolean add(String name) {
        if (!valid(name)) return false;
        if (!names().contains(name)) {
            NAMES.add(name);
            save();
        }
        return true;
    }

    public static void remove(String name) {
        names().remove(name);
        save();
    }

    public static String current() {
        return Minecraft.getInstance().getUser().getName();
    }

    public static boolean isOriginalActive() {
        return original == null;
    }

    public static void switchTo(String name) {
        if (!valid(name)) return;
        Minecraft mc = Minecraft.getInstance();
        if (original == null) {
            original = mc.getUser();
            originalKeys = mc.profileKeyPairManager;
        }
        mc.user = new User(name, UUIDUtil.createOfflinePlayerUUID(name), "0", Optional.empty(), Optional.empty(), User.Type.LEGACY);
        // ключи чата старого аккаунта не подходят к новому UUID
        mc.profileKeyPairManager = ProfileKeyPairManager.EMPTY_KEY_MANAGER;
    }

    public static void restoreOriginal() {
        if (original == null) return;
        Minecraft mc = Minecraft.getInstance();
        mc.user = original;
        mc.profileKeyPairManager = originalKeys;
        original = null;
        originalKeys = null;
    }
}

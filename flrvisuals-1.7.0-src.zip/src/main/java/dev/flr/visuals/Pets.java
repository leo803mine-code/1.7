package dev.flr.visuals;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;

/** Процедурные модели из кубиков (координаты в пикселях 1/16, y вверх, перед = -z): шапки и питомцы с анимацией. */
final class Pets {
    private static final float U = 1f / 16f;
    private static PoseStack ps;
    private static VertexConsumer vc;
    private static int light;
    private static final int BLK = 0xFF16161C, VIOLET = 0xFF7B3FD6, LILAC = 0xFFA879FF;

    private static float lookYaw, lookPitch;

    private Pets() {}

    private static float blink(float t) {
        return (t + 17f) % 95f < 4f ? 0.15f : 1f;
    }

    /** Поворот головы: смотрит туда же, куда игрок, плюс сам иногда оглядывается. */
    private static float headYaw(float t) {
        float scan = Mth.sin(t * 0.031f) * 18f * (0.5f + 0.5f * Mth.sin(t * 0.0113f));
        return Mth.clamp(-lookYaw, -45f, 45f) * 0.8f + scan;
    }

    private static float headPitch(float t) {
        return Mth.clamp(-lookPitch, -25f, 25f) * 0.6f + Mth.sin(t * 0.06f) * 2f;
    }

    private static float earFlick(float t) {
        return Mth.sin(t * 0.017f) > 0.85f ? Mth.sin(t * 0.9f) * 10f : 0f;
    }

    /** Сердечко над головой раз в ~18 секунд. */
    private static void heart(float t, float y) {
        float q = (t % 360f) / 360f / 0.22f;
        if (q > 1f) return;
        float s = Mth.sin(q * Mth.PI);
        if (s < 0.05f) return;
        ps.pushPose();
        ps.translate(0, (y + q * 8f) * U, 0);
        ps.scale(s, s, s);
        int c = 0xFFFF4F7B;
        box(-2, 3, -0.5f, -0.5f, 4, 0.5f, c); box(0.5f, 3, -0.5f, 2, 4, 0.5f, c);
        box(-2.5f, 2, -0.5f, 2.5f, 3, 0.5f, c);
        box(-1.5f, 1, -0.5f, 1.5f, 2, 0.5f, c);
        box(-0.5f, 0, -0.5f, 0.5f, 1, 0.5f, c);
        ps.popPose();
    }

    static void begin(PoseStack p, VertexConsumer v, int l) {
        ps = p; vc = v; light = l;
    }

    private static int shade(int c, float k) {
        return 0xFF000000 | (int) ((c >> 16 & 255) * k) << 16 | (int) ((c >> 8 & 255) * k) << 8 | (int) ((c & 255) * k);
    }

    private static void face(PoseStack.Pose pp, int c, float k, float nx, float ny, float nz, float[] v) {
        int col = shade(c, k);
        for (int i = 0; i < 4; i++) {
            vc.addVertex(pp.pose(), v[i * 3], v[i * 3 + 1], v[i * 3 + 2]).setColor(col).setUv(0f, 0f)
                    .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pp, nx, ny, nz);
        }
    }

    static void box(float x0, float y0, float z0, float x1, float y1, float z1, int c) {
        x0 *= U; y0 *= U; z0 *= U; x1 *= U; y1 *= U; z1 *= U;
        PoseStack.Pose p = ps.last();
        face(p, c, 1.0f, 0, 1, 0, new float[]{x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1});
        face(p, c, 0.5f, 0, -1, 0, new float[]{x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1});
        face(p, c, 0.8f, 0, 0, -1, new float[]{x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0});
        face(p, c, 0.8f, 0, 0, 1, new float[]{x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1});
        face(p, c, 0.65f, -1, 0, 0, new float[]{x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0});
        face(p, c, 0.65f, 1, 0, 0, new float[]{x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0});
    }

    private static void part(float px, float py, float pz, float rx, float ry, float rz, Runnable r) {
        ps.pushPose();
        ps.translate(px * U, py * U, pz * U);
        if (ry != 0) ps.mulPose(Axis.YP.rotationDegrees(ry));
        if (rx != 0) ps.mulPose(Axis.XP.rotationDegrees(rx));
        if (rz != 0) ps.mulPose(Axis.ZP.rotationDegrees(rz));
        r.run();
        ps.popPose();
    }

    // ---------------- шапки (в пространстве головы, верх головы y = 8) ----------------
    static void hat(int type, float t) {
        ps.pushPose();
        ps.scale(1, -1, 1);
        if (type == 1) {
            final int RED = 0xFFD92B3A, WHITE = 0xFFF6F6FA;
            box(-4.8f, 8, -4.8f, 4.8f, 10.4f, 4.8f, WHITE);
            float[] w = {4.2f, 3.5f, 2.7f, 1.9f}, dz = {0, 0.8f, 2.2f, 4.0f};
            for (int i = 0; i < 4; i++) {
                float yb = 10.4f + 2.5f * i;
                box(-w[i], yb, -w[i] + dz[i], w[i], yb + 2.5f, w[i] + dz[i], RED);
            }
            float sw = Mth.sin(t * 0.1f) * 1.2f;
            box(-1.6f + sw, 17.7f, 4.4f, 1.6f + sw, 20.9f, 7.6f, WHITE);
        } else if (type == 2) {
            box(-4.5f, 8, -4.5f, 4.5f, 11.2f, 4.5f, BLK);
            box(-4.55f, 10.4f, -4.55f, 4.55f, 10.8f, 4.55f, VIOLET);
            box(-1.4f, 9, -4.6f, 1.4f, 10.2f, -4.5f, VIOLET);
            box(-4.2f, 8, -8.8f, 4.2f, 8.9f, -4.5f, BLK);
            box(-3.6f, 8.3f, -9.4f, 3.6f, 8.9f, -8.8f, BLK);
            box(-0.7f, 11.2f, -0.7f, 0.7f, 11.9f, 0.7f, VIOLET);
            box(-1.6f, 8, 4.5f, 1.6f, 9.4f, 5.1f, BLK);
        } else {
            box(-4.7f, 8, -4.7f, 4.7f, 9.9f, 4.7f, 0xFF2A2A33);
            box(-4.55f, 9.9f, -4.55f, 4.55f, 12.4f, 4.55f, BLK);
            box(-4.6f, 10.5f, -4.6f, 4.6f, 10.9f, 4.6f, VIOLET);
            box(-3.4f, 12.4f, -3.4f, 3.4f, 13.4f, 3.4f, BLK);
            box(-1.2f, 13.4f, -1.2f, 1.2f, 14.4f, 1.2f, BLK);
        }
        ps.popPose();
    }

    // ---------------- куртка и предметы на спине ----------------
    static void jacketBody() {
        ps.pushPose();
        ps.scale(1, -1, 1);
        box(-4.45f, -12.3f, -2.45f, 4.45f, 0.25f, 2.45f, BLK);
        box(-4.5f, -12.4f, -2.5f, 4.5f, -10.7f, 2.5f, VIOLET);
        box(-3f, 0.2f, -2.6f, 3f, 1.3f, 2.6f, VIOLET);
        box(-0.35f, -11.2f, -2.55f, 0.35f, 0.25f, -2.45f, LILAC);
        box(-3.3f, -9.3f, -2.55f, -1.2f, -8.9f, -2.45f, VIOLET);
        box(1.2f, -9.3f, -2.55f, 3.3f, -8.9f, -2.45f, VIOLET);
        box(-0.5f, -10.5f, 2.46f, 0.5f, -1.2f, 2.55f, LILAC);
        ps.popPose();
    }

    static void jacketArm(boolean right) {
        ps.pushPose();
        ps.scale(1, -1, 1);
        float x0 = right ? -3.45f : -1.45f, x1 = right ? 1.45f : 3.45f;
        box(x0, -10.4f, -2.45f, x1, 2.4f, 2.45f, BLK);
        box(x0 - 0.05f, -10.45f, -2.5f, x1 + 0.05f, -8.7f, 2.5f, VIOLET);
        box(x0 - 0.05f, 0.9f, -2.5f, x1 + 0.05f, 1.3f, 2.5f, LILAC);
        ps.popPose();
    }

    static void back(int type, float t) {
        ps.pushPose();
        ps.scale(1, -1, 1);
        final int GOLD = 0xFFE3B23C, BROWN = 0xFF6B3F1D, BLADE = 0xFFDCE6F2, EDGE = 0xFFF8FBFF;
        final int RED = 0xFFD92B3A, WHT = 0xFFF6F6FA, GREEN = 0xFF2E9B55;
        if (type == 1) {
            part(0, -5.5f, 3.9f, 0, 0, 40f, () -> {
                box(-1.0f, -11f, -0.5f, 1.0f, -9.6f, 0.7f, GOLD);
                box(-0.7f, -9.6f, -0.4f, 0.7f, -6.6f, 0.6f, BROWN);
                box(-3f, -6.6f, -0.8f, 3f, -5.4f, 0.9f, GOLD);
                box(-1.4f, -5.4f, -0.5f, 1.4f, 10f, 0.6f, BLADE);
                box(-0.9f, 10f, -0.45f, 0.9f, 12f, 0.55f, BLADE);
                box(-0.4f, 12f, -0.4f, 0.4f, 13f, 0.5f, BLADE);
                box(-0.25f, -5.4f, 0.6f, 0.25f, 12.2f, 0.75f, EDGE);
            });
        } else if (type == 2) {
            part(0, -5.5f, 3.9f, 0, 0, 35f, () -> {
                for (int i = 0; i < 8; i++) box(-1.1f, -10f + i * 2.4f, -0.9f, 1.1f, -10f + (i + 1) * 2.4f, 0.9f, i % 2 == 0 ? RED : WHT);
                box(-1.1f, 9.2f, -0.9f, 1.1f, 11.6f, 0.9f, RED);
                box(-1.1f, 11.6f, -0.9f, 3.9f, 13.8f, 0.9f, WHT);
                box(2.0f, 9.2f, -0.9f, 4.2f, 11.6f, 0.9f, RED);
                box(-1.7f, -2.4f, -1.2f, 1.7f, 0.6f, 1.2f, GREEN);
                box(-0.6f, -1.4f, 1.1f, 0.6f, -0.4f, 1.5f, RED);
            });
        } else {
            part(0, -6.2f, 3.8f, 0, 0, 0, () -> {
                final int PR = 0xFFB86B2B, PD = 0xFF8F4E1E;
                for (int side = -1; side <= 1; side += 2) {
                    for (int i = 0; i < 14; i++) {
                        double a = i * Math.PI * 2 / 14;
                        float cx = side * 3.5f + (float) Math.cos(a) * 3.3f, cy = -2.5f + (float) Math.sin(a) * 3.3f;
                        box(cx - 1.1f, cy - 1.1f, -0.7f, cx + 1.1f, cy + 1.1f, 0.7f, i % 3 == 0 ? PD : PR);
                    }
                }
                part(0, 1.5f, 0, 0, 0, 38f, () -> box(-0.9f, -4.5f, -0.9f, 0.9f, 4.5f, 0.9f, PR));
                part(0, 1.5f, 0, 0, 0, -38f, () -> box(-0.9f, -4.5f, -1.2f, 0.9f, 4.5f, 0.6f, PD));
                box(-1.9f, 5.0f, -0.9f, 1.9f, 7.2f, 0.9f, PR);
                box(-4.5f, -1.2f, 0.7f, -3.5f, -0.4f, 1.1f, WHT); box(3.5f, -3.4f, 0.7f, 4.5f, -2.6f, 1.1f, WHT);
                box(-0.4f, 2.2f, 0.7f, 0.6f, 3.0f, 1.1f, WHT);
                box(-2.4f, 6.4f, -1.0f, -0.6f, 8.4f, 1.0f, RED); box(0.6f, 6.4f, -1.0f, 2.4f, 8.4f, 1.0f, RED);
            });
        }
        ps.popPose();
    }

    // ---------------- питомцы (начало координат — у ног, y вверх) ----------------
    static void pet(int type, float t, float ph, float walk, float netYaw, float pitch) {
        lookYaw = netYaw;
        lookPitch = pitch;
        switch (type) {
            case 1 -> rabbit(t, ph, walk);
            case 2 -> cat(t, ph, walk);
            case 3 -> jaguar(t, ph, walk);
            case 4 -> penguin(t, ph, walk);
            case 5 -> door(t);
            default -> { }
        }
    }

    private static void rabbit(float t, float ph, float walk) {
        final int G = 0xFF8F94A6, G2 = 0xFF7C8196, GL = 0xFF9CA2B6, W = 0xFFEDEDF3;
        float w = Math.min(1f, walk * 2f);
        float hop = walk > 0.05f ? Math.abs(Mth.sin(ph * 0.9f)) * 2.8f * w : 0f;
        float br = Mth.sin(t * 0.08f) * 0.25f;
        float pitchB = Mth.sin(ph * 0.9f + 0.6f) * 11f * w;
        final float hy = headYaw(t), hp = headPitch(t), k = blink(t);
        final float eb = Mth.sin(ph * 0.9f + 1.2f) * 9f * w;
        final float sw = Mth.sin(t * 0.07f) * 4f + earFlick(t), nw = 0.5f + Mth.sin(t * 0.7f) * 0.15f;
        ps.pushPose();
        ps.translate(0, hop * U, 0);
        ps.translate(0, 4 * U, 0);
        ps.mulPose(Axis.XP.rotationDegrees(pitchB));
        ps.translate(0, -4 * U, 0);
        box(-3, 2, -3, 3, 7 + br, 4, G);
        box(-3.7f, 1, 1, -2.3f, 5, 4.6f, G); box(2.3f, 1, 1, 3.7f, 5, 4.6f, G);
        part(0, 6, -2.5f, hp, hy, 0, () -> {
            box(-2.8f, 0, -4, 2.8f, 5, 1, GL);
            box(-3.2f, 0.5f, -3.5f, 3.2f, 2.8f, 0.5f, GL);
            box(-2.5f, 3 - k, -4.05f, -0.7f, 3 + k, -4f, 0xFFB8B066); box(0.7f, 3 - k, -4.05f, 2.5f, 3 + k, -4f, 0xFFB8B066);
            box(-2.1f, 3.05f - 0.75f * k, -4.1f, -1.1f, 3.05f + 0.75f * k, -4.05f, 0xFF0E0E14);
            box(1.1f, 3.05f - 0.75f * k, -4.1f, 2.1f, 3.05f + 0.75f * k, -4.05f, 0xFF0E0E14);
            if (k > 0.5f) {
                box(-1.8f, 3.3f, -4.12f, -1.5f, 3.6f, -4.1f, 0xFFFFFFFF); box(1.5f, 3.3f, -4.12f, 1.8f, 3.6f, -4.1f, 0xFFFFFFFF);
            }
            box(-nw, 0.8f, -4.15f, nw, 1.6f, -4.05f, 0xFFD79A8C);
            part(-2.7f, 4.6f, -1.5f, 0, 0, -22f + sw - eb, () -> box(-1.4f, -5.8f, -1.2f, 0.2f, 0, 1.2f, G));
            part(2.7f, 4.6f, -1.5f, 0, 0, 22f - sw + eb, () -> box(-0.2f, -5.8f, -1.2f, 1.4f, 0, 1.2f, G));
        });
        box(-2.5f, 0, -3, -0.8f, 2.2f, -1.2f, G); box(0.8f, 0, -3, 2.5f, 2.2f, -1.2f, G);
        box(-2.5f, 0, -3.3f, -0.8f, 0.9f, -1.2f, W); box(0.8f, 0, -3.3f, 2.5f, 0.9f, -1.2f, W);
        box(-3.7f, 0, 0.5f, -2.3f, 1.2f, 4.8f, G2); box(2.3f, 0, 0.5f, 3.7f, 1.2f, 4.8f, G2);
        float tw = Mth.sin(t * 0.25f) * 0.5f;
        box(-1.2f + tw, 3, 4, 1.2f + tw, 5.4f, 6.2f, W);
        heart(t, 13);
        ps.popPose();
    }

    private static void cat(float t, float ph, float walk) {
        final int B = 0xFFE29A4B, BL = 0xFFF6EFE6, D = 0xFFB5651F;
        float w = Math.min(1f, walk * 2f), sit = 1f - Mth.clamp(walk * 5f, 0f, 1f);
        final float hy = headYaw(t), hp = headPitch(t), k = blink(t), ear = earFlick(t);
        float stride = ph * 0.8f, swing = 40f * w, bob = Math.abs(Mth.sin(stride)) * 0.7f * w;
        ps.pushPose();
        ps.translate(0, (bob - sit * 1.6f) * U, 0);
        ps.pushPose();
        ps.translate(0, 3.5f * U, 3.5f * U);
        ps.mulPose(Axis.XP.rotationDegrees(sit * 32f));
        ps.translate(0, -3.5f * U, -3.5f * U);
        box(-2.5f, 3.5f, -4, 2.5f, 8, 4, B);
        box(-2, 3.5f, -3.5f, 2, 4.2f, 3.5f, BL);
        for (float z : new float[]{-2.5f, -0.5f, 1.5f, 3f}) box(-2.5f, 8, z, 2.5f, 8.15f, z + 0.8f, D);
        for (int i = 0; i < 2; i++) {
            float x = i == 0 ? -1.7f : 1.7f, a = Mth.sin(stride + i * Mth.PI) * swing;
            part(x, 3.6f, -3f, a, 0, 0, () -> { box(-0.9f, -3.6f, -0.9f, 0.9f, 0, 0.9f, B); box(-0.9f, -3.6f, -1.2f, 0.9f, -2.6f, 0.9f, BL); });
        }
        part(0, 7, -3.6f, hp, hy, 0, () -> {
            box(-3, 0, -4.4f, 3, 5, 0.4f, B);
            box(-1.6f, 0.4f, -5f, 1.6f, 2.6f, -4.4f, BL);
            part(-2f, 5, -1.8f, 0, 0, ear, () -> box(-0.8f, 0, -0.6f, 0.8f, 2.2f, 0.6f, B));
            part(2f, 5, -1.8f, 0, 0, -ear, () -> box(-0.8f, 0, -0.6f, 0.8f, 2.2f, 0.6f, B));
            box(-2.3f, 3.2f - 0.6f * k, -4.45f, -0.9f, 3.2f + 0.6f * k, -4.4f, 0xFF9BE070);
            box(0.9f, 3.2f - 0.6f * k, -4.45f, 2.3f, 3.2f + 0.6f * k, -4.4f, 0xFF9BE070);
            box(-1.8f, 3.2f - 0.5f * k, -4.5f, -1.3f, 3.2f + 0.5f * k, -4.45f, 0xFF101014);
            box(1.3f, 3.2f - 0.5f * k, -4.5f, 1.8f, 3.2f + 0.5f * k, -4.45f, 0xFF101014);
            box(-0.5f, 1.6f, -5.05f, 0.5f, 2.2f, -4.95f, 0xFFD99AA0);
        });
        ps.popPose();
        for (int i = 0; i < 2; i++) {
            float x = i == 0 ? -1.7f : 1.7f, a = Mth.sin(stride + (1 - i) * Mth.PI) * swing * (1f - sit) + sit * 70f;
            part(x, 3.6f, 2.5f, a, 0, 0, () -> { box(-0.9f, -3.6f, -0.9f, 0.9f, 0, 0.9f, B); box(-0.9f, -3.6f, -1.2f, 0.9f, -2.6f, 0.9f, BL); });
        }
        float wag = Mth.sin(t * (0.1f + walk * 0.12f)) * 18f;
        part(0, 7, 4, -30f + sit * 55f, wag, 0, () -> {
            box(-0.7f, -0.7f, 0, 0.7f, 0.7f, 3.5f, B);
            part(0, 0, 3.5f, -25f + sit * 30f, wag * 0.8f, 0, () -> {
                box(-0.7f, -0.7f, 0, 0.7f, 0.7f, 3.5f, B);
                box(-0.75f, -0.75f, 2.6f, 0.75f, 0.75f, 3.5f, D);
            });
        });
        heart(t, 15);
        ps.popPose();
    }

    /** Ягуар в пропорциях ванильного оцелота: длинное узкое тело, тонкие лапы, длинный хвост. */
    private static void jaguar(float t, float ph, float walk) {
        final int B = 0xFFDDB45E, BL = 0xFFF2E6C8, D = 0xFF5A3D1E;
        float w = Math.min(1f, walk * 2f), stride = ph * 0.9f, sw = 42f * w;
        float bob = Math.abs(Mth.sin(stride)) * 0.8f * w, breathe = Mth.sin(t * 0.08f) * 0.2f;
        final float hy = headYaw(t), hp = headPitch(t) + Mth.sin(stride) * 3f * w, k = blink(t), ear = earFlick(t);
        ps.pushPose();
        ps.translate(0, bob * U, 0);
        box(-2, 6, -6, 2, 11 + breathe, 6, B);
        box(-1.6f, 5.8f, -5.5f, 1.6f, 6.4f, 5.5f, BL);
        float[][] sp = {{-1.2f, -4}, {1, -2.6f}, {-0.8f, -0.8f}, {1.2f, 1}, {-1, 2.8f}, {0.8f, 4.6f}, {-1.3f, 5.4f}};
        for (float[] q : sp) box(q[0] - 0.55f, 11 + breathe, q[1] - 0.55f, q[0] + 0.55f, 11.15f + breathe, q[1] + 0.55f, D);
        for (float z : new float[]{-4.5f, -1.8f, 1.2f, 4f}) {
            box(2f, 8.4f, z - 0.5f, 2.15f, 9.6f, z + 0.5f, D);
            box(-2.15f, 7.6f, z + 0.3f, -2f, 8.8f, z + 1.3f, D);
        }
        float[][] legs = {{-1.2f, -4.6f, 0}, {1.2f, -4.6f, Mth.PI}, {-1.2f, 4.6f, Mth.PI}, {1.2f, 4.6f, 0}};
        for (float[] l : legs) {
            float a = Mth.sin(stride + l[2]) * sw;
            part(l[0], 6.2f, l[1], a, 0, 0, () -> { box(-1, -6.2f, -1, 1, 0, 1, B); box(-1, -6.2f, -1.3f, 1, -5f, 1, BL); });
        }
        part(0, 10, -6.2f, hp, hy, 0, () -> {
            box(-2.5f, -2, -4.6f, 2.5f, 2.2f, 0.4f, B);
            box(-1.5f, -1.4f, -6.2f, 1.5f, 0.2f, -4.6f, BL);
            part(-1.8f, 2.2f, -0.8f, 0, 0, ear, () -> box(-0.8f, 0, -0.6f, 0.8f, 1.8f, 0.6f, B));
            part(1.8f, 2.2f, -0.8f, 0, 0, -ear, () -> box(-0.8f, 0, -0.6f, 0.8f, 1.8f, 0.6f, B));
            box(-2.1f, 0.6f - 0.6f * k, -4.66f, -0.9f, 0.6f + 0.6f * k, -4.6f, 0xFFB8E36B);
            box(0.9f, 0.6f - 0.6f * k, -4.66f, 2.1f, 0.6f + 0.6f * k, -4.6f, 0xFFB8E36B);
            box(-1.6f, 0.6f - 0.5f * k, -4.7f, -1.1f, 0.6f + 0.5f * k, -4.66f, 0xFF101014);
            box(1.1f, 0.6f - 0.5f * k, -4.7f, 1.6f, 0.6f + 0.5f * k, -4.66f, 0xFF101014);
            box(-0.5f, -0.8f, -6.3f, 0.5f, -0.2f, -6.2f, 0xFF3A2A22);
            box(-0.8f, 1.6f, -4.5f, -0.2f, 2.3f, -4.4f, D); box(0.2f, 1.6f, -4.5f, 0.8f, 2.3f, -4.4f, D);
        });
        float wag = Mth.sin(t * (0.09f + walk * 0.1f)) * 14f;
        part(0, 10.5f, 6, -35f, wag, 0, () -> {
            box(-0.5f, -0.5f, 0, 0.5f, 0.5f, 7, B);
            box(-0.55f, -0.55f, 2f, 0.55f, 0.55f, 3f, D);
            part(0, 0, 7, 55f, wag * 0.6f, 0, () -> {
                box(-0.5f, -0.5f, 0, 0.5f, 0.5f, 7, B);
                box(-0.55f, -0.55f, 3f, 0.55f, 0.55f, 4f, D);
                box(-0.6f, -0.6f, 6f, 0.6f, 0.6f, 7f, D);
            });
        });
        heart(t, 18);
        ps.popPose();
    }

    private static void penguin(float t, float ph, float walk) {
        final int GR = 0xFF7D828E, DK = 0xFF474B56, BE = 0xFFD8DAE2, OR = 0xFFE9953A;
        float w = Math.min(1f, walk * 2f);
        float sway = Mth.sin(ph * 0.8f) * 8f * w + Mth.sin(t * 0.04f) * 1.5f;
        float flap = Mth.sin(t * 0.1f) * 3f + w * Mth.sin(ph * 0.8f + 1.5f) * 22f + (Mth.sin(t * 0.021f) > 0.9f ? Mth.sin(t * 0.8f) * 22f : 0f);
        final float hy = headYaw(t) * 1.2f, hp = headPitch(t) + Mth.sin(t * 0.05f) * 1.2f, k = blink(t);
        float foot = Mth.sin(ph * 0.8f) * 30f * w, hopI = Mth.sin(t * 0.017f) > 0.92f ? Math.abs(Mth.sin(t * 0.7f)) * 2f : 0f;
        ps.pushPose();
        ps.translate(0, (Math.abs(Mth.sin(ph * 0.8f)) * 0.8f * w + hopI) * U, 0);
        ps.scale(0.85f, 0.85f, 0.85f);
        part(0, 0, 0, 0, 0, sway, () -> {
            box(-3.2f, 1, -2.7f, 3.2f, 6.6f, 2.7f, GR);
            box(-2.4f, 1.4f, -2.75f, 2.4f, 6.2f, -2.7f, BE);
            box(-1.3f, 1, 2.7f, 1.3f, 2.6f, 3.9f, DK);
            part(0, 6.6f, 0, hp, hy, 0, () -> {
                box(-3.2f, 0, -2.8f, 3.2f, 4.2f, 2.8f, DK);
                box(-2.2f, 1.9f, -2.85f, -0.8f, 3.3f, -2.8f, 0xFFF2F2F6);
                box(0.8f, 1.9f, -2.85f, 2.2f, 3.3f, -2.8f, 0xFFF2F2F6);
                box(-1.7f, 2.6f - 0.5f * k, -2.9f, -1.2f, 2.6f + 0.5f * k, -2.85f, 0xFF0E0E14);
                box(1.2f, 2.6f - 0.5f * k, -2.9f, 1.7f, 2.6f + 0.5f * k, -2.85f, 0xFF0E0E14);
                box(-1, 0.8f, -4.4f, 1, 1.9f, -2.8f, OR);
            });
            part(-3.4f, 5.6f, 0, 0, 0, -(10f + flap), () -> box(-1, -3.8f, -1.3f, 0, 0, 1.3f, DK));
            part(3.4f, 5.6f, 0, 0, 0, 10f + flap, () -> box(0, -3.8f, -1.3f, 1, 0, 1.3f, DK));
            part(-1.5f, 1, 0.3f, foot, 0, 0, () -> box(-1, -1, -2.4f, 1, 0.2f, 0.4f, OR));
            part(1.5f, 1, 0.3f, -foot, 0, 0, () -> box(-1, -1, -2.4f, 1, 0.2f, 0.4f, OR));
        });
        heart(t, 14);
        ps.popPose();
    }

    private static void door(float t) {
        final int WH = 0xFFF4F4F8, WS = 0xFFDADCE6, FR = 0xFFC9CBD6, GD = 0xFFE3C15A, CR = 0xFF55586A;
        float bob = Mth.sin(t * 0.05f) * 0.6f, swing = Mth.sin(t * 0.035f) * 12f - 6f;
        ps.pushPose();
        ps.translate(0, bob * U, 0);
        box(-6, 0, -1, -5, 21, 1, FR);
        box(5, 0, -1, 6, 13, 1, FR); box(5, 16.5f, -1, 6, 21, 1, FR);
        box(-6, 20, -1, 2, 21, 1, FR);
        part(-5, 0, 0, 0, swing, 0, () -> {
            box(0, 0, -0.7f, 10, 15, 0.7f, WH);
            box(0, 15, -0.7f, 6.5f, 20, 0.7f, WH);
            box(6.5f, 15, -0.7f, 8.5f, 17.5f, 0.7f, WH);
            box(1.2f, 1.5f, -0.8f, 8.8f, 8.5f, -0.7f, WS); box(1.2f, 10.5f, -0.8f, 5.8f, 18.5f, -0.7f, WS);
            box(8.1f, 9.2f, -1.5f, 9.4f, 10.6f, -0.7f, GD);
            box(5.8f, 10.5f, -0.85f, 6.2f, 13f, -0.8f, CR); box(6.2f, 13f, -0.85f, 7.4f, 13.4f, -0.8f, CR);
            box(2.4f, 3f, -0.85f, 2.8f, 6.5f, -0.8f, CR); box(2.8f, 6.5f, -0.85f, 4f, 6.9f, -0.8f, CR);
        });
        box(2, 0, -3, 3.4f, 0.6f, -2.2f, WH); box(-2, 0, 2, -0.8f, 0.5f, 3.2f, WS); box(6, 0, -2, 7, 0.8f, -1.2f, WH);
        ps.popPose();
    }
}

package dev.flr.visuals;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public final class FlrKeys {
    private static final String CAT = "key.categories.flrvisuals";
    public static final KeyMapping MENU = new KeyMapping("key.flrvisuals.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, CAT);
    public static final KeyMapping MASTER = new KeyMapping("key.flrvisuals.master", InputConstants.Type.KEYSYM, InputConstants.UNKNOWN.getValue(), CAT);
    public static final KeyMapping SOUND = new KeyMapping("key.flrvisuals.sound", InputConstants.Type.KEYSYM, InputConstants.UNKNOWN.getValue(), CAT);
    public static final KeyMapping AUTOSWAP = new KeyMapping("key.flrvisuals.autoswap", InputConstants.Type.KEYSYM, InputConstants.UNKNOWN.getValue(), CAT);
    public static final KeyMapping ZOOM = new KeyMapping("key.flrvisuals.zoom", InputConstants.Type.KEYSYM, 67, CAT);
}

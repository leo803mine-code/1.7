package dev.flr.visuals;

/**
 * Процедурные перьевые крылья, 4 разных типа.
 * Класс не зависит от Minecraft: он только выдаёт четырёхугольники (quad) в Sink.
 *
 * Система координат модели игрока: x - вправо, y - ВНИЗ (0 = линия плеч), z+ = назад (спина).
 * Голова: y от -0.5 до 0. Туловище: y от 0 до 0.75.
 */
public final class WingModel {

    public static final int TYPES = 4;
    public static final String[] NAMES = {"Angel", "Demon", "Dark", "Crystal"};

    public interface Sink {
        /** xyz: 12 float (4 вершины), argb: 4 цвета. */
        void quad(float[] xyz, int[] argb);
    }

    // ---- крепление к спине ----
    static final float ROOT_X = 0.07f;
    static final float ROOT_Y = 0.06f;   // чуть ниже плеч (раньше 0.10 + crouch, крылья уходили выше головы)
    static final float ROOT_Z = 0.215f;

    // ---- пользовательские настройки (выставляются слоем перед build; только render-поток) ----
    public static float optAlpha = 1f, optFlap = 1f, optAngle = 0f, optGap = 0f, optY = 0f, optZ = 0f;
    private static float curRootX = ROOT_X;
    /** Расстояние корня крыла от центра спины по типам . */
    private static final float[] ROOTS = {0.07f, 0.07f, 0.07f, 0.07f};

    // ---- буферы без аллокаций ----
    private static final float[] CU = new float[8], CV = new float[8], NU = new float[8], NV = new float[8], WW = new float[8];
    private static final int[] CC = new int[8], CE = new int[8];
    private static final float[] XYZ = new float[12], PC = new float[3], PL = new float[3], PR = new float[3],
            PC2 = new float[3], PL2 = new float[3], PR2 = new float[3];
    private static final int[] COL = new int[4];  // задняя грань нагрудника = 0.1875, раньше было 0.16 -> крылья были внутри брони

    // ---- форма пера ----
    static final int ROUND = 0, SPIKE = 1, KITE = 2, BLADE = 3;
    static final float[][] RINGS = {
            {0f, 0.14f, 0.32f, 0.52f, 0.72f, 0.88f, 1f},  // ROUND
            {0f, 0.2f, 0.5f, 0.8f, 1f},                   // SPIKE
            {0f, 0.45f, 1f},                              // KITE
            {0f, 0.25f, 0.5f, 0.75f, 1f}                  // BLADE
    };
    static final float[][] RINGS_LOD = {
            {0f, 0.35f, 0.7f, 1f},
            {0f, 0.45f, 1f},
            {0f, 0.45f, 1f},
            {0f, 0.5f, 1f}
    };

    private static float profile(int shape, float s) {
        switch (shape) {
            case ROUND: {
                // овальное перо с узким основанием и мягким кончиком
                double t = Math.pow(s, 0.62);
                return (float) Math.pow(Math.sin(Math.PI * t), 0.75);
            }
            case SPIKE:
                return s < 0.2f ? s / 0.2f : (float) Math.pow(1.0 - (s - 0.2f) / 0.8f, 1.35);
            case KITE:
                return s < 0.45f ? s / 0.45f : (1f - s) / 0.55f;
            default: // BLADE
                return 1f - s * s * 0.92f;
        }
    }

    // ---- описание типов ----
    private interface ColorFn { int get(int accent); }

    private record Row(int count, float t0, float t1, float a0, float a1,
                       float len0, float len1, float hump, float wid, float curl,
                       int shape, float z, float rag, float wave,
                       ColorFn base, ColorFn tip, float edgeShade, boolean facet) {}

    private record Spec(float armAngle, float armLen, float bow, float rigid, Row[] rows) {}

    private static final Spec[] SPECS = new Spec[TYPES];

    static {
        // 0 ANGEL - классические большие белые крылья: 3 слоя овальных перьев
        ColorFn white = a -> mix(0xFFFFFFFF, a, 0.22f);
        ColorFn whiteTip = a -> alpha(0xFFFFFFFF, 235);
        ColorFn soft = a -> alpha(mix(0xFFFFFFFF, a, 0.45f), 245);
        SPECS[0] = new Spec(30f, 0.50f, 0.10f, 1f, new Row[]{
                new Row(9, 0.28f, 1.00f, -80f, 6f, 0.74f, 0.80f, 0.16f, 0.150f, -0.22f, ROUND, 0f, 0.05f, 0f, white, whiteTip, 0.62f, false),
                new Row(8, 0.18f, 0.95f, -86f, -6f, 0.52f, 0.58f, 0.10f, 0.145f, -0.18f, ROUND, 0.006f, 0.05f, 0f, soft, whiteTip, 0.70f, false),
                new Row(8, 0.10f, 0.96f, -82f, 10f, 0.26f, 0.28f, 0.04f, 0.100f, -0.12f, ROUND, 0.012f, 0.04f, 0f,
                        a -> alpha(mix(0xFFFFFFFF, a, 0.55f), 250), whiteTip, 0.74f, false)
        });

        // 1 DEMON - острые, хищные, загнутые перья: мало, но длинные
        ColorFn dBase = a -> alpha(0x2A0A12, 245);
        ColorFn dTip = a -> alpha(a, 255);
        SPECS[1] = new Spec(36f, 0.55f, 0.20f, 1f, new Row[]{
                new Row(6, 0.15f, 1.00f, -64f, 14f, 0.92f, 0.52f, 0.20f, 0.160f, 0.34f, SPIKE, 0f, 0.07f, 0f, dBase, dTip, 0.70f, false),
                new Row(5, 0.10f, 0.72f, -92f, -42f, 0.46f, 0.58f, 0.06f, 0.140f, -0.22f, SPIKE, 0.006f, 0.05f, 0f,
                        a -> alpha(0x14050A, 250), a -> alpha(mix(a, 0xFF000000, 0.35f), 255), 0.70f, false),
                new Row(4, 0.40f, 0.96f, 58f, 34f, 0.20f, 0.24f, 0f, 0.075f, 0.20f, SPIKE, 0.012f, 0.05f, 0f,
                        dBase, a -> alpha(mix(0xFFFFFFFF, a, 0.6f), 255), 0.75f, false)
        });

        // 2 DARK - ворон: много плотных узких перьев, свисают вниз, фиолетовый отлив на концах
        ColorFn kBase = a -> alpha(0x100E1A, 250);
        ColorFn kTip = a -> alpha(mix(a, 0xFF7A63D6, 0.55f), 250);
        SPECS[2] = new Spec(22f, 0.50f, 0.06f, 0.9f, new Row[]{
                new Row(12, 0.20f, 1.00f, -93f, -10f, 0.84f, 0.64f, 0.10f, 0.150f, -0.30f, ROUND, 0f, 0.13f, 0f, kBase, kTip, 0.78f, false),
                new Row(11, 0.15f, 0.95f, -96f, -20f, 0.58f, 0.48f, 0.06f, 0.145f, -0.26f, ROUND, 0.005f, 0.12f, 0f,
                        a -> alpha(a, 250), kTip, 0.80f, false),
                new Row(9, 0.10f, 0.95f, -88f, 8f, 0.30f, 0.30f, 0.04f, 0.120f, -0.15f, ROUND, 0.010f, 0.10f, 0f,
                        a -> alpha(mix(a, 0xFF000000, 0.4f), 250), kTip, 0.82f, false)
        });

        // 3 CRYSTAL - жёсткие гранёные осколки (ромбы), две грани разного оттенка, почти не машут
        ColorFn cLight = a -> alpha(mix(a, 0xFFFFFFFF, 0.50f), 225);
        ColorFn cTip = a -> alpha(mix(a, 0xFFFFFFFF, 0.15f), 190);
        SPECS[3] = new Spec(34f, 0.52f, 0f, 0.4f, new Row[]{
                new Row(7, 0.20f, 1.00f, -72f, 14f, 0.88f, 0.62f, 0.14f, 0.165f, 0f, KITE, 0f, 0.05f, 0f, cLight, cTip, 0.55f, true),
                new Row(6, 0.15f, 0.90f, -82f, -4f, 0.50f, 0.44f, 0.06f, 0.150f, 0f, KITE, 0.006f, 0.05f, 0f, cLight, cTip, 0.50f, true),
                new Row(4, 0.30f, 0.95f, -60f, 30f, 0.24f, 0.24f, 0f, 0.110f, 0f, KITE, 0.012f, 0.05f, 0f, cLight, cTip, 0.55f, true)
        });

    }

    // =====================================================================
    //  Состояние для плавной анимации (одно на игрока)
    // =====================================================================
    public static final class State {
        public float spread = 0.6f;   // 0 = сложены, 1 = раскрыты
        public float amp = 0.1f;      // амплитуда взмаха
        public float speed = 1.5f;    // скорость взмаха, рад/с
        public float crouch;          // 0..1, плавный присед
        public float phase;           // накопленная фаза
        public long lastNanos;
        public long lastSeenMs;

        /** Экспоненциальное сглаживание: не зависит от FPS и убирает резкие скачки. */
        public void update(float dt, float tSpread, float tAmp, float tSpeed, float tCrouch) {
            spread += (tSpread - spread) * k(dt, 5f);
            amp += (tAmp - amp) * k(dt, 4f);
            speed += (tSpeed - speed) * k(dt, 3.5f);
            crouch += (tCrouch - crouch) * k(dt, 12f);
            phase += speed * dt;
            if (phase > 6283f) phase -= 6283f;
        }

        private static float k(float dt, float rate) {
            return 1f - (float) Math.exp(-rate * dt);
        }
    }

    // =====================================================================
    //  Построение
    // =====================================================================

    /**
     * @param side   +1 правое крыло, -1 левое
     * @param size   Config.scale * Config.wingSize
     * @param accent основной цвет (ARGB)
     * @param lod    true = упрощённая геометрия для далёких игроков
     */
    public static void build(int type, int side, float size, State st, int accent, boolean lod, Sink out) {
        int ty = Math.max(0, Math.min(TYPES - 1, type));
        Spec sp = SPECS[ty];
        curRootX = ROOTS[ty];
        float fold = 1f - st.spread;
        float amp = st.amp * sp.rigid * optFlap;
        float phase = st.phase;
        float armA = (float) Math.toRadians(lerp(sp.armAngle, 82f, fold));
        float armL = sp.armLen * (1f - 0.15f * fold);

        float[] xyz = XYZ;
        int[] col = COL;
        float[][] ring = lod ? RINGS_LOD : RINGS;

        for (int r = 0; r < sp.rows.length; r++) {
            Row row = sp.rows[r];
            for (int i = 0; i < row.count; i++) {
                float f = row.count == 1 ? 0f : i / (float) (row.count - 1);
                float t = lerp(row.t0, row.t1, f);

                // основание пера на дуге-«кости» крыла
                float ax = armL * t * (float) Math.cos(armA);
                float ay = armL * t * (float) Math.sin(armA);
                float bowOff = sp.bow * (float) Math.sin(Math.PI * t) * armL;
                float bu = ax - bowOff * (float) Math.sin(armA);
                float bv = ay + bowOff * (float) Math.cos(armA);

                // угол: при складывании все перья стремятся вниз вдоль спины
                float a0 = lerp(row.a0, row.a1, f);
                a0 = a0 + fold * (-92f - a0) * 0.88f;
                float lag = phase - 0.95f * t - 0.5f * f;
                float flap = amp * 0.75f * (float) Math.sin(lag);
                float ang = (float) Math.toRadians(a0) + flap;

                float rag = 1f + row.rag * (float) Math.sin(i * 12.9898f + r * 4.1f);
                float len = (lerp(row.len0, row.len1, f) + row.hump * (float) Math.sin(Math.PI * f)) * rag
                        * (1f - 0.20f * fold);
                float wid = row.wid * (1f - 0.18f * fold);

                float vary = 1f + 0.09f * (float) Math.sin((i + r * 5) * 2.7f);   // каждое перо чуть светлее/темнее
                int cBase = fade(scale(row.base.get(accent), vary));
                int cTip = fade(scale(row.tip.get(accent), vary));
                feather(out, xyz, col, ring[row.shape], row.shape, side, size, sp, st, amp, phase,
                        bu, bv, ang, len, wid, row.curl * (1f - 0.5f * fold), row.wave,
                        row.z, cBase, cTip, row.edgeShade, row.facet, i + r * 17);
            }
        }
    }

    private static void feather(Sink out, float[] xyz, int[] col, float[] S, int shape, int side, float size,
                                Spec sp, State st, float amp, float phase,
                                float bu, float bv, float ang, float len, float wid, float curl, float wave,
                                float zLayer, int cBase, int cTip, float edgeShade, boolean facet, int seed) {
        int n = S.length;
        float[] cu = CU, cv = CV, nu = NU, nv = NV, w = WW;
        float u = bu, v = bv;
        cu[0] = u;
        cv[0] = v;
        float a = ang;
        for (int i = 0; i < n; i++) {
            float s = S[i];
            if (i > 0) {
                float sm = (S[i] + S[i - 1]) * 0.5f;
                a = ang + curl * sm + wave * (float) Math.sin(phase * 2.2f + sm * 5f + seed * 0.9f);
                float ds = S[i] - S[i - 1];
                u += (float) Math.cos(a) * len * ds;
                v += (float) Math.sin(a) * len * ds;
                cu[i] = u;
                cv[i] = v;
            }
            nu[i] = -(float) Math.sin(a);
            nv[i] = (float) Math.cos(a);
            w[i] = wid * profile(shape, s);
        }

        int[] cc = CC, ce = CE;
        for (int i = 0; i < n; i++) {
            int base = mixArgb(cBase, cTip, S[i]);
            cc[i] = scale(base, 1.10f);
            ce[i] = scale(base, edgeShade);
        }

        float[] pc = PC, pl = PL, pr = PR;
        float[] pc2 = PC2, pl2 = PL2, pr2 = PR2;
        for (int i = 0; i < n - 1; i++) {
            place(pc, cu[i], cv[i], zLayer, S[i], len, side, size, amp, phase, st);
            place(pl, cu[i] + nu[i] * w[i], cv[i] + nv[i] * w[i], zLayer, S[i], len, side, size, amp, phase, st);
            place(pr, cu[i] - nu[i] * w[i], cv[i] - nv[i] * w[i], zLayer, S[i], len, side, size, amp, phase, st);
            place(pc2, cu[i + 1], cv[i + 1], zLayer, S[i + 1], len, side, size, amp, phase, st);
            place(pl2, cu[i + 1] + nu[i + 1] * w[i + 1], cv[i + 1] + nv[i + 1] * w[i + 1], zLayer, S[i + 1], len, side, size, amp, phase, st);
            place(pr2, cu[i + 1] - nu[i + 1] * w[i + 1], cv[i + 1] - nv[i + 1] * w[i + 1], zLayer, S[i + 1], len, side, size, amp, phase, st);

            int lc0 = facet ? ce[i] : cc[i], lc1 = facet ? ce[i + 1] : cc[i + 1];
            // левая половина: C_i, C_i+1, L_i+1, L_i
            put(xyz, 0, pc); put(xyz, 3, pc2); put(xyz, 6, pl2); put(xyz, 9, pl);
            if (facet) {
                int lit = scale(mixArgb(cBase, cTip, S[i]), 1.18f);
                int lit2 = scale(mixArgb(cBase, cTip, S[i + 1]), 1.18f);
                col[0] = lit; col[1] = lit2; col[2] = lit2; col[3] = lit;
            } else {
                col[0] = cc[i]; col[1] = cc[i + 1]; col[2] = ce[i + 1]; col[3] = ce[i];
            }
            out.quad(xyz, col);
            // правая половина: R_i, R_i+1, C_i+1, C_i
            put(xyz, 0, pr); put(xyz, 3, pr2); put(xyz, 6, pc2); put(xyz, 9, pc);
            if (facet) {
                int drk = scale(mixArgb(cBase, cTip, S[i]), edgeShade);
                int drk2 = scale(mixArgb(cBase, cTip, S[i + 1]), edgeShade);
                col[0] = drk; col[1] = drk2; col[2] = drk2; col[3] = drk;
            } else {
                col[0] = scale(ce[i], 0.88f); col[1] = scale(ce[i + 1], 0.88f); col[2] = cc[i + 1]; col[3] = cc[i];
            }
            out.quad(xyz, col);
        }
    }

    /** Плоскость крыла (u наружу, v вверх) -> координаты модели игрока. */
    private static void place(float[] o, float u, float v, float zLayer, float s, float len,
                              int side, float size, float amp, float phase, State st) {
        float dist = Math.min(1f, (float) Math.hypot(u, v) / 1.7f);
        // базовый загиб назад + бегущая волна от плеча к кончику (кончики запаздывают)
        float th = 0.20f + st.spread * 0.10f + optAngle + amp * (float) Math.sin(phase - 1.2f * dist);
        float uu = u * size;
        float vv = v * size;
        float bow = 0.10f * s * s * len * size;   // кончики пера чуть загибаются назад
        // x ограничен снизу: крылья никогда не заходят за центр спины и не «застревают» друг в друге
        o[0] = side * Math.max(0.05f, curRootX + optGap + uu * (float) Math.cos(th));
        o[1] = ROOT_Y + optY - vv;
        o[2] = ROOT_Z + optZ + zLayer * size + uu * (float) Math.sin(th) + bow;
    }

    // ---- мелочи ----
    private static void put(float[] dst, int off, float[] p) {
        dst[off] = p[0];
        dst[off + 1] = p[1];
        dst[off + 2] = p[2];
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static int fade(int c) {
        if (optAlpha >= 0.999f) return c;
        int a = Math.round(((c >>> 24) & 255) * Math.max(0f, optAlpha));
        return (a << 24) | (c & 0xFFFFFF);
    }

    static int alpha(int c, int a) {
        return (Math.max(0, Math.min(255, a)) << 24) | (c & 0xFFFFFF);
    }

    static int mix(int a, int b, float t) {
        return mixArgb(a | 0xFF000000, b | 0xFF000000, t);
    }

    static int mixArgb(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = Math.round(((a >>> 24) & 255) * (1 - t) + ((b >>> 24) & 255) * t);
        int rr = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int gg = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bb = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (aa << 24) | (rr << 16) | (gg << 8) | bb;
    }

    static int scale(int c, float f) {
        int r = Math.min(255, Math.round(((c >> 16) & 255) * f));
        int g = Math.min(255, Math.round(((c >> 8) & 255) * f));
        int b = Math.min(255, Math.round((c & 255) * f));
        return (c & 0xFF000000) | (r << 16) | (g << 8) | b;
    }
}

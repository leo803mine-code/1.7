package dev.flr.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Скруглённая плашка-уведомление над хотбаром (броня, Auto Swap). */
public final class Notify {
    private record Msg(String text, int color, long start) {}

    private static final long LIFE = 3200L;
    private static Msg cur;

    private Notify() {}

    public static void show(String text, int rgb) {
        cur = new Msg(text, rgb & 0xFFFFFF, System.currentTimeMillis());
    }

    public static void render(GuiGraphics g) {
        Msg m = cur;
        Minecraft mc = Minecraft.getInstance();
        if (m == null || mc.options.hideGui) return;
        long age = System.currentTimeMillis() - m.start;
        if (age > LIFE) { cur = null; return; }
        float in = Math.min(1f, age / 260f), out = Math.min(1f, (LIFE - age) / 450f);
        float a = Math.min(in, out);
        if (a < 0.03f) return;
        int w = mc.font.width(m.text) + 36, h = 22;
        int x = (g.guiWidth() - w) / 2, y = g.guiHeight() - 66 + (int) ((1f - in) * 12f);
        int c = m.color;
        CosmeticsScreen.rrect(g, x - 1, y - 1, w + 2, h + 2, 12, ((int) (a * 110) << 24) | c);
        CosmeticsScreen.rrect(g, x, y, w, h, 11, ((int) (a * 236) << 24) | 0x11121B);
        CosmeticsScreen.rrect(g, x + 9, y + 7, 8, 8, 4, ((int) (a * 255) << 24) | c);
        g.drawString(mc.font, m.text, x + 24, y + 7, ((Math.max(8, (int) (a * 255))) << 24) | 0xFFFFFF, false);
    }
}
